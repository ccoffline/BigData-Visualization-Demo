package com.example.demo.model.charts;

public class Scatter extends Coordinate {
}
