package com.example.demo.model.field;

public class Name extends Category{
}