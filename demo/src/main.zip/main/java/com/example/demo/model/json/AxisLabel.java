package com.example.demo.model.json;

public class AxisLabel {

    private String formatter;

    public String getFormatter() {
        return formatter;
    }

    public AxisLabel setFormatter(String formatter) {
        this.formatter = formatter;
        return this;
    }
}
