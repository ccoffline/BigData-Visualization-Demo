package com.example.demo.model.charts;

import com.example.demo.model.field.Field;

public class Line extends Coordinate {
}
