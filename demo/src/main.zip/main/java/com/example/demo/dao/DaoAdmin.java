package com.example.demo.dao;

import com.google.gson.Gson;

public class DaoAdmin {

    public static void main(String[] args) {
    }
}
