var legend = {
  orient: "horizontal",
  x: "center",
  y: 30,
  data: []
};

export default { legend };
