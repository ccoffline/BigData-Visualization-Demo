var series = {
  name: "",
  type: "",
  data: []
};

export default { series };
