var option = {
  title: {
    text: "",
    subtext: ""
  },
  legend: {
    data: []
  },
  grid: null,
  xAxis: [],
  yAxis: [],
  series: []
};

export default { option };
