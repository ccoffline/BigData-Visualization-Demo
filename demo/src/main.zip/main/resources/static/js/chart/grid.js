var grid = {
  x: "0%",
  x2: "5%",
  y: "60",
  y2: "5",
  containLabel: true
};

export default { grid };
