<template>
  <el-container>
    <el-main>
    </el-main>
    <el-footer>
    </el-footer>
  </el-container>
</template>

<script>
export default {
  name: "ChartBuilder",
  created() {},
  data() {
    return {};
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
