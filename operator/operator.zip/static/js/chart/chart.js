var chart = {
  title: null,
  legend: null,
  grid: null,
  xAxis: [],
  yAxis: [],
  series: []
};

export default { chart };
