var title = {
  text: "",
  subtext: "",
  x="left",
  y="top",
};

export default { title };
